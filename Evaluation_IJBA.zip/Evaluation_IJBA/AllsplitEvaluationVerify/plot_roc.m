% You can reproduce our single model (ResNext 152 trained on our own face dataset illustrated by our arXiv paper 
% :"A Good Practice Towards Top Performance of Face Recognition: Transferred Deep Feature Fusion") results based on score matrix given by
% corresponding folders. Due to the limitation of company, we can not
% provide ResNext 152 and SE-ResNext 101 models. Moreover, all the features
% of IJBA data and Template Adaptation models will relase later (too many files need to be uploaded, so they will not come recently)
% Coded by Lin Xiong and Jian Zhao May-5, 2018
function auc = plot_roc(predict,groundtruth,saveTxtPath,beta)
    pos_num = sum (groundtruth == 1);
    neg_num = sum (groundtruth == 0);
    
    m = size(groundtruth , 1);
    [pre,index] = sort(predict);
    groundtruth = groundtruth (index);
    x = zeros (m+1,1);
    y = zeros (m+1,1);
    auc = 0;
    x(1) = 1;
    y(1) = 1;
    
    TP = 0;
    FP = 0;

    for i = m:-1:2
        % TP = sum(groundtruth(i:m)==1);
        % FP = sum(groundtruth(i:m)==0);
        if groundtruth(i) == 1
            TP = TP + 1;
        else
            FP = FP + 1;
        end
        x(i) = FP / neg_num;
        y(i) = TP / pos_num;
        auc = auc + (y(i)+y(i-1))*(x(i-1)-x(i))/2;
    end
    
    x(m+1) = 0;
    y(m+1) = 0;
    
    I00001 = find(abs(x-0.0001) <= 1e-5) %1e-4
%     I0001= find(x==0.0010)
    I0001 = find(abs(x-0.001) <= 1e-5)
%     I001 = find(x==0.0100)
    I001  = find(abs(x-0.01) <= 1e-4)
%     I01  = find(x==0.1000)
    I01   = find(abs(x-0.1) <= 1e-4)
    Y00001=y(I00001(1))
    Y0001= y(I0001(1))
    Y001 = y(I001(1))
    Y01  = y(I01(1))
    auc = auc + y(m) * x(m)/2;
    plot(x,y,'b','LineWidth',2)
    semilogx(x,y,'b','LineWidth',2)
    ylim([0.6 1])
    xlim([1e-4 1])
    hold on
    xlabel ('FAR')
    ylabel ('TAR')
    text(0.1,Y01,strcat('\leftarrow ',num2str(Y01)))
    text(0.01,Y001,strcat('\leftarrow ',num2str(Y001)))
    text(0.001,Y0001,strcat('\leftarrow ',num2str(Y0001)))
    text(0.0001,Y00001,strcat('\leftarrow ',num2str(Y00001)))
    
    fw = fopen(strcat(saveTxtPath,'_','Beta_',num2str(beta),'_TA_verify.txt'),'a');
    fprintf(fw,'\n%f\t%f\t%f\t%f\n', Y00001, Y0001, Y001, Y01);
    fclose(fw);
    
end