%% IJBA Evaluation codes on all 10 splits for face verification task with Template Adaptation(mean coding for video frames)
% You can reproduce our single model (ResNext 152 trained on our own face dataset illustrated by our arXiv paper 
% :"A Good Practice Towards Top Performance of Face Recognition: Transferred Deep Feature Fusion") results based on score matrix given by
% corresponding folders. Due to the limitation of company, we can not
% provide ResNext 152 and SE-ResNext 101 models. Moreover, all the features
% of IJBA data and Template Adaptation models will relase later (too many files need to be uploaded, so they will not come recently)
% Coded by Lin Xiong and Jian Zhao May-5, 2018

clc
clear all;
model_path_dir = '../models/_template_resnext/';
for sp = 1:10
    clear S_PQ;
    clear pair_labels;
    addpath(strcat(model_path_dir,'split',int2str(sp),'//'))

    mkdir(strcat(model_path_dir,'split',int2str(sp),'//Results_RSX152'))
    load(strcat(model_path_dir,'.//split',int2str(sp),'//probe.txt'))		% one face comes from pairs (Template ID on testing data)
	load(strcat(model_path_dir,'.//split',int2str(sp),'//reference.txt'))		% another face comes from pairs (Template ID on testing data)
    load(strcat(model_path_dir,'.//split',int2str(sp),'//media_subject_test'));
    media_subject_test = reshape(media_subject_test,[],1);
    load(strcat(model_path_dir,'.//split',int2str(sp),'//template_media_test'));
    
    TEMPLATE_ID = load(strcat(model_path_dir,'./split',int2str(sp),'/test_TEMPLATE_ID.txt'));
    MEDIA_ID = load(strcat(model_path_dir,'./split',int2str(sp),'/test_MEDIA_ID.txt'));
    unique_template_id = unique(TEMPLATE_ID);
    unique_media_id = unique(MEDIA_ID);

    savePath = strcat(model_path_dir,'.//split',int2str(sp),'//Results_RSX152','//result');
    saveTxtPath = strcat(model_path_dir,'.//split',int2str(sp),'//Results_RSX152','//result');

    beta = 0;
	S_PQ = zeros(size(probe,1), 1);
	pair_labels = zeros(size(probe));
    for i=1:size(probe,1)

		pair_1 = probe(i);             % template_id for each pair
		pair_2 = reference(i);

        pair_1_index=find(unique_template_id==pair_1); % find the relative template_id
		pair_2_index=find(unique_template_id==pair_2);
		pair1_m = template_media_test{pair_1_index}; % find the features based on media for a template
		pair2_m = template_media_test{pair_2_index};
        for p1 = 1:size(pair1_m)
            pair_1_i = find(unique_media_id == pair1_m(p1));
            p1_subjectID = media_subject_test(pair_1_i);
        end
        for p2 = 1:size(pair2_m)
            pair_2_i = find(unique_media_id == pair2_m(p2));
            p2_subjectID = media_subject_test(pair_2_i);
        end
        if p1_subjectID == p2_subjectID
            pair_labels(i) = 1;
        else
            pair_labels(i) = 0;
        end
	    
    end

    load(strcat(model_path_dir,'split',int2str(sp),'/ScoreMatrix_RSX152/','S_PQ_V_','Beta_',num2str(beta),'_','split',int2str(sp),'.mat'));

	auc = plot_roc(S_PQ,pair_labels,saveTxtPath,beta)
	saveas(gcf,strcat(savePath,'_','Beta_',num2str(beta),'_TA_verify.png'))
end



